### Meridian CI lane: `quality-gate`

- Result: `failed`
- Exit code: `1`
- Run attempt: `local`; commit: `local`
- Dependency cache hit: `not reported`
- Reproduce: `bash scripts/ci.sh --lane quality-gate`
- Queue time: available after completion through `ci-metrics.py`; excluded from step durations.

| Step | Status | Exit code | Duration (s) |
| --- | --- | ---: | ---: |
| Verify .NET SDK | passed | 0 | 1 |
| Verify Python | passed | 0 | 0 |
| Restore .NET solution | passed | 0 | 4 |
| Verify .NET formatting | passed | 0 | 41 |
| Validate warning suppression inventory | passed | 0 | 0 |
| Enforce ApiClientService caller ratchet | passed | 0 | 1 |
| Enforce no-new-god-file ratchet | passed | 0 | 0 |
| Enforce consolidated-helper duplication ratchet | passed | 0 | 5 |
| Enforce inline SHA-256 hashing ratchet | passed | 0 | 1 |
| Enforce posture-environment test serialization | passed | 0 | 2 |
| Enforce server-derived ActionOrigin at endpoints | passed | 0 | 0 |
| Enforce declared file-store concurrency postures | passed | 0 | 1 |
| Enforce ledger-book-native accounting scope | passed | 0 | 1 |
| Enforce ledger dimension coverage across surfaces | passed | 0 | 0 |
| Build web workstation .NET lane | passed | 0 | 9 |
| Run .NET non-integration test projects | passed | 0 | 618 |
| Validate browser evidence reader | passed | 0 | 0 |
| Verify Node.js | passed | 0 | 0 |
| Verify npm | passed | 0 | 0 |
| Verify Python | passed | 0 | 0 |
| Install dashboard dependencies from lockfile | passed | 0 | 8 |
| Generated UI contract drift gate | passed | 0 | 0 |
| Lint dashboard source | passed | 0 | 21 |
| Enforce strictNullChecks on dashboard source | passed | 0 | 39 |
| Run dashboard tests | failed | 1 | 5 |

#### .NET test summary

- Total .NET slices: 19
- Passed: 19
- Failed: 0
- Test counts: {"passed": 18973, "failed": 0, "skipped": 5, "other": 0}

#### Known failure classification

- Dashboard npm or Vitest lane failed.

#### First useful failure lines

- `⎯⎯⎯⎯⎯⎯ Failed Suites 1 ⎯⎯⎯⎯⎯⎯⎯`
- `Error: [postcss] It looks like you're trying to use `tailwindcss` directly as a PostCSS plugin. The PostCSS plugin has moved to a separate package, so to continue using Tailwind CSS with PostCSS you'll need to install...`
- `Test Files  1 failed | 7 passed (8)`

#### Artifact roots

- `artifacts/ci-summary/`
- `artifacts/build-logs/` when a build lane ran
- `artifacts/test-results/` when a test lane ran
