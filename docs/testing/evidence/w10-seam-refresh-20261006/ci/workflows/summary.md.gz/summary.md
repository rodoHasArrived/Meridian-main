### Meridian CI lane: `verify-workflows`

- Result: `passed`
- Exit code: `0`
- Run attempt: `local`; commit: `local`
- Dependency cache hit: `not reported`
- Reproduce: `bash scripts/ci.sh --lane verify-workflows`
- Queue time: available after completion through `ci-metrics.py`; excluded from step durations.

| Step | Status | Exit code | Duration (s) |
| --- | --- | ---: | ---: |
| Verify Python | passed | 0 | 0 |
| Validate Actions syntax with actionlint | passed | 0 | 0 |
| Check script test dependencies | passed | 0 | 0 |
| Validate lane manifest | passed | 0 | 0 |
| Validate lane vocabulary | passed | 0 | 0 |
| Validate workflow hygiene | passed | 0 | 0 |
| Validate test skip register | passed | 0 | 2 |
| Run repo script test suite (quarantine-aware) | passed | 0 | 738 |

#### Artifact roots

- `artifacts/ci-summary/`
- `artifacts/build-logs/` when a build lane ran
- `artifacts/test-results/` when a test lane ran
